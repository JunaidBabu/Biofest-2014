<div class="border_box">
		<div class="row">
		<div class="span12" style="color:#000; text-align: center; height:60px;">
		<h3>Sponsorship Queries:</h3>
		</div>
		</div><br>
		<div class="row">
	<div class="span6 offset3" style="text-align:center;">
	<strong>Contact:</strong><br>
<br>
Akshit : 9884469085
<br>
Shalin : 9962292640
<br><i>corporate.relations@biofest.in</i>
	</div>