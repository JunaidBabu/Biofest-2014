<div class="row">
  <div class="col-md-6">
	  	
	<iframe id="ytplayer" type="text/html" width="100%" height="80%" src="http://www.youtube.com/embed/rE_4BQo4f1s?autoplay=0&amp;origin=http://biofest.in" frameborder="0" style="
    padding-top: 25;
"></iframe>
</div>
  <div class="col-md-6">
  	<h1>Welcome to Biofest 2014</h1>
<p>
After a successful 2nd

events for students to identify and showcase their talent. After a prosperous outcome from 

the first two editions, Department of Biotechnology, IIT Madras would be privileged to invite 

your students to represent your college on this national platform. Please find attached a brief 

description of events which we believe you would be interested in taking part. Apart from 

these we will be organizing certified workshops during Biofest. Biofest 2014 also brings back 

an array of lectures and video conferences, catering to the various aspects of the modern day 

research in biological sciences and biological engineering streams. We believe that this will be 

an amazing opportunity for your students to learn from and interact with the best.

 edition, Biofest returns with its 3rd

 edition with much more exciting
 </p>
  </div>
</div>