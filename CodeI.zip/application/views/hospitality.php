<div class="border_box" style="text-align: justify; padding:20px;">

			<p>Welcome to the fun filled <strong>Biofest 2014</strong>. The hospitality team is here to make your stay comfortable and pleasant. We constantly strive to make your stay a memorable one. However, in order to enable us to assist you in the best possible way we will require a little cooperation from your side. Firstly, please ensure that you register with us, in the absence of which we will not be able to provide you accommodation. Secondly, since our capacity is limited we advise you to register asap!!!
<br><br>
We look forward to have a great time with you!!!<br>
</p><div class="row-fluid">

</div>
<strong>Queries:</strong><br>

The Hospitality Team is here to guide you throughout your stay with us. In case of any queries please feel free to contact us :<br><br>

<strong>Prathyusha Konda 7200631666<br>
<a href="mailto:hospitality@biofest.in" target="blank">
hospitality@biofest.in</a></strong>
<p></p>

		</div>