<div class="border_box" style="text-align: justify; padding:20px;">

			<p>


General Queries:<br><br>

Drop us a mail at <strong><a href="mailto:student.relations@biofest.in" target="blank">
student.relations@biofest.in</a></strong><br>
 We will get back to you within 24 hours.<br><br>


</p>

		</div>